# Hypixel Skyblock Clean Crystal Hollows World Save

All randomly placed structures removed by using different world saves where no structures were in that location\
All stone is removed\
Made in 1.20.1 and converted to 1.8.9 by Ythien\
Click [here](https://github.com/Campionnn/CleanCH) for the 1.20.1 version

Feel free to use to make routes or in other projects where you need something like this

## How to download
1. Click the green "Code" button near the top right
2. Click "Download ZIP"
3. Create a new folder inside your minecraft saves directory named whatever you like
4. Unzip the file you downloaded into there
