# SkyBlock Mining Route Generator

This tool generates optimized mining routes for Hypixel SkyBlock, compatible with Soopy and ColeWeight mods. It minimizes vertical movement and zigzagging, supporting both ores and gemstones.

## Features
- Generates routes for ores (e.g., coal, iron) and gemstones (e.g., ruby, sapphire).
- Supports circular routes for gemstones.
- Reduces vertical and lateral movement for efficiency.
- Exports routes in Soopy/ColeWeight JSON format.

## Installation
Install via pip:
```bash
pip install skyblock-mining-routes