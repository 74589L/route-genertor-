

import os
import json
import math
from nbt.region import RegionFile
import time
import numpy as np
from tqdm import tqdm
import random


# Normal config (settings you change often)
output_dir = r""  # Where to save the route files most likely somthing like this: c:\Users\...\....\skyblock-mining-routes\waypoints
world_folder = r""  # Path to Minecraft world folder most likely somthing like this : c:\Users\.....\.....\skyblock-mining-routes\CleanCH-1.8.9
which_ore = "coal"  # Ore to mine (coal, iron, gold, etc.)
route_length = 234  # Number of waypoints per route
num_routes = 1  # Number of routes to generate
circular_routes = False  # False for ores, True for gemstones
preferred_direction = "Z"  # Preferred direction of travel ("X" or "Z" for forward progress)

# Advanced config (fine-tuning the algorithm)
max_jump_distance = 25  # Max distance between waypoints (increased for better connectivity)
min_vein_size = 6  # Min blocks in a vein to consider (reduced to include more veins)
max_y = 63  # Max Y-level to search for ores (adjusted to match Minecraft layer boundaries)
max_distance = 3  # Max distance between blocks to form a vein (increased to form larger veins)
cell_size = 20  # Grid cell size for spatial indexing (increased for better performance)
radius = 15  # Radius for finding intermediate veins (increased to find more options)
max_intermediate = 4  # Max intermediate veins between two waypoints (balanced for path quality)
lookahead_depth = 4  # How far to look ahead when scoring waypoints (increased for better route planning)
transition_threshold = 0.6  # When to start returning in circular routes (adjusted for better circle shape)
y_weight = 2.5  # Weight for penalizing Y-differences (increased for flatter routes)
max_y_diff = 4  # Max allowed Y-difference in post-processing (reduced for smoother vertical transitions)
smoothing_passes = 3  # Number of smoothing passes in post-processing (increased for better smoothing)
direction_weight = 1.5  # Weight for rewarding progress in the preferred direction (increased to reduce backtracking)
lateral_penalty = 0.8  # Penalty for lateral movement (increased to promote straighter paths)

os.makedirs(output_dir, exist_ok=True)

# Block IDs for ores and gemstones
ore_types = {
    "coal": (16, 0),
    "iron": (15, 0),
    "gold": (14, 0),
    "diamond": (56, 0),
    "lapis": (21, 0),
    "redstone": (73, 0),
    "emerald": (129, 0),
    "ruby": (95, 14),
    "amber": (95, 1),
    "topaz": (95, 4),
    "jade": (95, 5),
    "sapphire": (95, 3),
    "amethyst": (95, 10),
    "jasper": (95, 6),
    "opal": (95, 0)
}

gemstone_types = ["ruby", "amber", "topaz", "jade", "sapphire", "amethyst", "jasper", "opal"]

pane_ore_types = {ore: (160, data) for ore, (block_id, data) in ore_types.items() if ore in gemstone_types}

all_waypoints = []  # Store all waypoints

def extract_ore_locations(world_folder, target_block_id, target_data_value, max_y=max_y):
    """Extract locations of the specified ore under Y=max_y from the world."""
    global all_waypoints
    ore_waypoints = []
    region_folder = os.path.join(world_folder, "region")
    if not os.path.exists(region_folder):
        print(f"Region folder not found at {region_folder}")
        return ore_waypoints

    region_files = [f for f in os.listdir(region_folder) if f.endswith(".mca")]

    for filename in tqdm(region_files, desc="Processing region files"):
        if filename.endswith(".mca"):
            region_file = os.path.join(region_folder, filename)
            try:
                rx, rz = map(int, filename[2:-4].split('.'))
                region = RegionFile(region_file)
                for chunk_x in range(32):
                    for chunk_z in range(32):
                        try:
                            chunk = region.get_chunk(chunk_x, chunk_z)
                            if chunk is None:
                                print(f"Chunk ({chunk_x}, {chunk_z}) in {filename} is None")
                                continue
                            world_chunk_x = rx * 32 + chunk_x
                            world_chunk_z = rz * 32 + chunk_z
                            level = chunk["Level"]
                            if "Sections" not in level:
                                print(f"No Sections in chunk ({chunk_x}, {chunk_z}) in {filename}")
                                continue
                            sections = level["Sections"]
                            for section in sections:
                                y_base = section["Y"].value * 16
                                if "Blocks" not in section or "Data" not in section:
                                    print(f"Missing Blocks or Data in section Y={y_base} in {filename}")
                                    continue
                                blocks = section["Blocks"].value
                                data = section["Data"].value
                                for i, block_id in enumerate(blocks):
                                    if block_id == target_block_id:
                                        data_byte = data[i // 2]
                                        data_value = (data_byte & 0x0F) if (i % 2 == 0) else ((data_byte >> 4) & 0x0F)
                                        if data_value == target_data_value:
                                            y_offset = (i // 256) % 16
                                            z_offset = (i // 16) % 16
                                            x_offset = i % 16
                                            world_x = world_chunk_x * 16 + x_offset
                                            world_y = y_base + y_offset
                                            world_z = world_chunk_z * 16 + z_offset
                                            if world_y <= max_y:
                                                ore_waypoints.append({'x': world_x, 'y': world_y, 'z': world_z})
                                                all_waypoints.append({'x': world_x, 'y': world_y, 'z': world_z})
                        except Exception as e:
                            print(f"Error processing chunk ({chunk_x}, {chunk_z}) in {filename}: {e}")
            except Exception as e:
                print(f"Error processing region file {filename}: {e}")

    print(f"Found {len(ore_waypoints)} {which_ore} blocks under Y={max_y}")
    if not ore_waypoints:
        print(f"Debug: No {which_ore} blocks found. Check world data or max_y ({max_y}).")
    return ore_waypoints

def group_into_veins(waypoints, max_distance=max_distance):
    """Group ore blocks into veins based on proximity using a grid-based approach."""
    if not waypoints:
        return []

    print("Grouping ore blocks into veins...")
    grid = {}
    cell_size = max_distance * 2

    for idx, point in enumerate(waypoints):
        try:
            cell_x = int(point['x'] // cell_size)
            cell_y = int(point['y'] // cell_size)
            cell_z = int(point['z'] // cell_size)
            cell_key = (cell_x, cell_y, cell_z)
            if cell_key not in grid:
                grid[cell_key] = []
            grid[cell_key].append((idx, point))
        except (KeyError, TypeError) as e:
            continue

    veins = []
    processed = set()
    total = len(waypoints)

    for i in tqdm(range(total), desc="Grouping blocks into veins"):
        if i in processed:
            continue

        vein = [waypoints[i]]
        processed.add(i)
        queue = [i]

        while queue:
            current_idx = queue.pop(0)
            current = waypoints[current_idx]
            cell_x = int(current['x'] // cell_size)
            cell_y = int(current['y'] // cell_size)
            cell_z = int(current['z'] // cell_size)

            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    for dz in [-1, 0, 1]:
                        neighbor_cell = (cell_x + dx, cell_y + dy, cell_z + dz)
                        if neighbor_cell not in grid:
                            continue

                        for idx, candidate in grid[neighbor_cell]:
                            if idx in processed:
                                continue

                            dist = math.sqrt(
                                (current['x'] - candidate['x']) ** 2 +
                                (current['y'] - candidate['y']) ** 2 +
                                (current['z'] - candidate['z']) ** 2
                            )

                            if dist <= max_distance:
                                vein.append(candidate)
                                processed.add(idx)
                                queue.append(idx)

        if len(vein) >= min_vein_size:
            veins.append(vein)

    print(f"Completed grouping into {len(veins)} veins")
    return veins

def calculate_vein_centers(veins):
    """Calculate the center waypoint for each vein and add metadata."""
    print("Calculating vein center waypoints...")
    vein_centers = []

    for vein in veins:
        if not vein:
            continue

        center_x = round(sum(block['x'] for block in vein) / len(vein))
        center_y = round(sum(block['y'] for block in vein) / len(vein))
        center_z = round(sum(block['z'] for block in vein) / len(vein))

        vein_centers.append({
            'x': center_x,
            'y': center_y,
            'z': center_z,
            'size': len(vein)
        })

    return vein_centers

def find_optimal_starting_vein(vein_centers):
    """Find a good starting vein based on size and connectivity."""
    scores = []

    for i, vein in enumerate(vein_centers):
        neighbor_count = 0
        for j, other_vein in enumerate(vein_centers):
            if i == j:
                continue

            dist = math.sqrt(
                (vein['x'] - other_vein['x']) ** 2 +
                (vein['y'] - other_vein['y']) ** 2 +
                (vein['z'] - other_vein['z']) ** 2
            )

            if dist <= max_jump_distance:
                neighbor_count += 1

        score = vein['size'] + (neighbor_count * 2)
        scores.append((i, score))

    scores.sort(key=lambda x: -x[1])
    return scores[0][0]

def find_intermediate_veins(current, target, vein_grid, all_used_indices, route_indices, cell_size=cell_size, radius=radius,
                            max_intermediate=max_intermediate):
    """Find up to max_intermediate veins within radius blocks of the path from current to target."""
    intermediate_veins = []
    D = {'x': target['x'] - current['x'], 'y': target['y'] - current['y'], 'z': target['z'] - current['z']}
    len_D_sq = D['x'] ** 2 + D['y'] ** 2 + D['z'] ** 2

    if len_D_sq < 1e-6:
        return []

    len_D = math.sqrt(len_D_sq)
    steps = 15

    for step in range(1, steps):
        t = step / steps
        P = {'x': current['x'] + t * D['x'], 'y': current['y'] + t * D['y'], 'z': current['z'] + t * D['z']}
        cell_x = int(P['x'] // cell_size)
        cell_y = int(P['y'] // cell_size)
        cell_z = int(P['z'] // cell_size)

        for dx in range(-1, 2):
            for dy in range(-1, 2):
                for dz in range(-1, 2):
                    neighbor_cell = (cell_x + dx, cell_y + dy, cell_z + dz)
                    if neighbor_cell in vein_grid:
                        for idx, vein in vein_grid[neighbor_cell]:
                            if idx in all_used_indices or idx in route_indices:
                                continue

                            C = vein
                            t_c = ((C['x'] - current['x']) * D['x'] + (C['y'] - current['y']) * D['y'] +
                                   (C['z'] - current['z']) * D['z']) / len_D_sq

                            if 0 < t_c < 1:
                                P_proj = {
                                    'x': current['x'] + t_c * D['x'],
                                    'y': current['y'] + t_c * D['y'],
                                    'z': current['z'] + t_c * D['z']
                                }

                                dist = math.sqrt(
                                    (C['x'] - P_proj['x']) ** 2 +
                                    (C['y'] - P_proj['y']) ** 2 +
                                    (C['z'] - P_proj['z']) ** 2
                                )

                                if dist < radius:
                                    y_diff = abs(C['y'] - current['y'])
                                    y_penalty = y_diff * 0.5
                                    vein_quality = (C['size'] / (dist + 1)) - y_penalty
                                    intermediate_veins.append((t_c, idx, vein, vein_quality))

    seen_indices = set()
    unique_intermediate = []

    for t_c, idx, vein, quality in intermediate_veins:
        if idx not in seen_indices:
            seen_indices.add(idx)
            unique_intermediate.append((t_c, idx, vein, quality))

    unique_intermediate.sort(key=lambda x: (x[0], -x[3]))
    selected = unique_intermediate[:max_intermediate]

    return [idx for _, idx, _, _ in selected]

def generate_optimized_route(vein_centers, max_waypoints, is_circular=False):
    """Generate an optimized route with reduced vertical and zigzag movement."""
    vein_grid = {}
    for idx, point in enumerate(vein_centers):
        cell_x = int(point['x'] // cell_size)
        cell_y = int(point['y'] // cell_size)
        cell_z = int(point['z'] // cell_size)
        cell_key = (cell_x, cell_y, cell_z)

        if cell_key not in vein_grid:
            vein_grid[cell_key] = []

        vein_grid[cell_key].append((idx, point))

    start_idx = find_optimal_starting_vein(vein_centers)

    route = [start_idx]
    used_indices = set([start_idx])
    last_pos = vein_centers[start_idx]

    while len(route) < max_waypoints:
        current = vein_centers[route[-1]]

        potential_next = []
        for idx, vein in enumerate(vein_centers):
            if idx in used_indices:
                continue

            dist = math.sqrt(
                (current['x'] - vein['x']) ** 2 +
                (current['y'] - vein['y']) ** 2 +
                (current['z'] - vein['z']) ** 2
            )

            if dist <= max_jump_distance:
                y_diff = abs(current['y'] - vein['y'])
                # Vector from current to next waypoint
                vec = {'x': vein['x'] - current['x'], 'y': vein['y'] - current['y'], 'z': vein['z'] - current['z']}
                vec_magnitude = math.sqrt(vec['x'] ** 2 + vec['y'] ** 2 + vec['z'] ** 2)

                if vec_magnitude < 1e-6:
                    continue

                # Normalize the vector
                vec_norm = {
                    'x': vec['x'] / vec_magnitude,
                    'y': vec['y'] / vec_magnitude,
                    'z': vec['z'] / vec_magnitude
                }

                # Preferred direction vector (unit vector along preferred axis)
                if preferred_direction == "Z":
                    dir_vec = {'x': 0, 'y': 0, 'z': 1}
                else:  # "X"
                    dir_vec = {'x': 1, 'y': 0, 'z': 0}

                # Dot product for directional alignment (reward progress in preferred direction)
                dot_product = (vec_norm['x'] * dir_vec['x'] + vec_norm['y'] * dir_vec['y'] + vec_norm['z'] * dir_vec['z'])

                # Lateral movement (perpendicular to preferred direction)
                if preferred_direction == "Z":
                    lateral_dist = abs(vein['x'] - current['x'])
                else:  # "X"
                    lateral_dist = abs(vein['z'] - current['z'])

                potential_next.append((idx, vein, dist, y_diff, dot_product, lateral_dist))

        if not potential_next:
            break

        # Sort by a combination of distance, Y-difference, directional alignment, and lateral penalty
        potential_next.sort(key=lambda x: (
            x[2] +  # Distance
            y_weight * x[3] +  # Y-difference penalty
            lateral_penalty * x[5] -  # Lateral movement penalty
            direction_weight * x[4]  # Directional reward (dot product)
        ))

        candidates = potential_next[:min(20, len(potential_next))]

        if is_circular and len(route) >= transition_threshold * max_waypoints:
            start_vein = vein_centers[route[0]]
            current_progress = len(route) / max_waypoints

            return_weight = (current_progress - transition_threshold) / (1 - transition_threshold)
            return_weight = min(0.9, return_weight)

            best_idx = None
            best_score = float('-inf')

            for idx, vein, dist, y_diff, dot_product, lateral_dist in candidates:
                dist_to_start = math.sqrt(
                    (vein['x'] - start_vein['x']) ** 2 +
                    (vein['y'] - start_vein['y']) ** 2 +
                    (vein['z'] - start_vein['z']) ** 2
                )

                if len(route) >= 0.8 * max_waypoints and dist_to_start <= max_jump_distance:
                    best_idx = idx
                    break

                size_factor = vein['size'] / 10
                distance_factor = 1 / (dist + 1)
                return_factor = 1 / (dist_to_start + 1)
                y_penalty = y_weight * y_diff
                lateral_penalty_score = lateral_penalty * lateral_dist
                direction_reward = direction_weight * dot_product

                score = (1 - return_weight) * (size_factor * distance_factor - y_penalty - lateral_penalty_score + direction_reward) + \
                        return_weight * return_factor * 2

                if score > best_score:
                    best_score = score
                    best_idx = idx
        else:
            best_idx = None
            best_score = float('-inf')

            for idx, vein, dist, y_diff, dot_product, lateral_dist in candidates:
                size_factor = vein['size'] / 10
                distance_factor = 1 / (dist + 1)
                y_penalty = y_weight * y_diff
                lateral_penalty_score = lateral_penalty * lateral_dist
                direction_reward = direction_weight * dot_product
                base_score = size_factor * distance_factor - y_penalty - lateral_penalty_score + direction_reward

                if lookahead_depth > 1:
                    lookahead_score = 0
                    current_idx = idx
                    current_used = used_indices.copy()
                    current_used.add(idx)

                    for depth in range(1, lookahead_depth):
                        temp_current = vein_centers[current_idx]
                        temp_candidates = []

                        for temp_idx, temp_vein in enumerate(vein_centers):
                            if temp_idx in current_used:
                                continue

                            temp_dist = math.sqrt(
                                (temp_current['x'] - temp_vein['x']) ** 2 +
                                (temp_current['y'] - temp_vein['y']) ** 2 +
                                (temp_current['z'] - temp_vein['z']) ** 2
                            )

                            if temp_dist <= max_jump_distance:
                                temp_y_diff = abs(temp_current['y'] - temp_vein['y'])
                                temp_vec = {'x': temp_vein['x'] - temp_current['x'], 'y': temp_vein['y'] - temp_current['y'],
                                            'z': temp_vein['z'] - temp_current['z']}
                                temp_vec_magnitude = math.sqrt(temp_vec['x'] ** 2 + temp_vec['y'] ** 2 + temp_vec['z'] ** 2)

                                if temp_vec_magnitude < 1e-6:
                                    continue

                                temp_vec_norm = {
                                    'x': temp_vec['x'] / temp_vec_magnitude,
                                    'y': temp_vec['y'] / temp_vec_magnitude,
                                    'z': temp_vec['z'] / temp_vec_magnitude
                                }

                                if preferred_direction == "Z":
                                    temp_dir_vec = {'x': 0, 'y': 0, 'z': 1}
                                    temp_lateral_dist = abs(temp_vein['x'] - temp_current['x'])
                                else:  # "X"
                                    temp_dir_vec = {'x': 1, 'y': 0, 'z': 0}
                                    temp_lateral_dist = abs(temp_vein['z'] - temp_current['z'])

                                temp_dot_product = (temp_vec_norm['x'] * temp_dir_vec['x'] +
                                                   temp_vec_norm['y'] * temp_dir_vec['y'] +
                                                   temp_vec_norm['z'] * temp_dir_vec['z'])
                                temp_size_factor = temp_vein['size'] / 10
                                temp_distance_factor = 1 / (temp_dist + 1)
                                temp_y_penalty = y_weight * temp_y_diff
                                temp_lateral_penalty = lateral_penalty * temp_lateral_dist
                                temp_direction_reward = direction_weight * temp_dot_product
                                temp_score = temp_size_factor * temp_distance_factor - temp_y_penalty - temp_lateral_penalty + temp_direction_reward
                                temp_candidates.append((temp_idx, temp_score))

                        if not temp_candidates:
                            break

                        temp_candidates.sort(key=lambda x: -x[1])
                        next_idx, next_score = temp_candidates[0]

                        lookahead_score += next_score * (0.7 ** depth)
                        current_idx = next_idx
                        current_used.add(next_idx)

                    score = base_score * 0.7 + lookahead_score * 0.3
                else:
                    score = base_score

                if score > best_score:
                    best_score = score
                    best_idx = idx

        if best_idx is None:
            break

        intermediate_indices = find_intermediate_veins(
            current,
            vein_centers[best_idx],
            vein_grid,
            used_indices,
            set(route)
        )

        for idx in intermediate_indices:
            if len(route) >= max_waypoints:
                break
            route.append(idx)
            used_indices.add(idx)

        if len(route) < max_waypoints:
            route.append(best_idx)
            used_indices.add(best_idx)

        if is_circular and len(route) >= 0.7 * max_waypoints:
            last = vein_centers[route[-1]]
            start = vein_centers[route[0]]

            dist_to_start = math.sqrt(
                (last['x'] - start['x']) ** 2 +
                (last['y'] - start['y']) ** 2 +
                (last['z'] - start['z']) ** 2
            )

            if dist_to_start <= max_jump_distance and len(route) >= 0.75 * max_waypoints:
                print("Route forms a complete loop")
                break

    if is_circular and len(route) < max_waypoints and len(route) > 5:
        start = vein_centers[route[0]]
        remaining = max_waypoints - len(route)
        current = vein_centers[route[-1]]

        for _ in range(remaining):
            candidates = []
            for idx, vein in enumerate(vein_centers):
                if idx in used_indices:
                    continue

                g_score = math.sqrt(
                    (current['x'] - vein['x']) ** 2 +
                    (current['y'] - vein['y']) ** 2 +
                    (current['z'] - vein['z']) ** 2
                )

                if g_score > max_jump_distance:
                    continue

                y_diff = abs(current['y'] - vein['y'])
                h_score = math.sqrt(
                    (vein['x'] - start['x']) ** 2 +
                    (vein['y'] - start['y']) ** 2 +
                    (vein['z'] - start['z']) ** 2
                )

                y_penalty = y_weight * y_diff
                f_score = g_score + h_score - (vein['size'] / 10) + y_penalty
                candidates.append((idx, f_score))

            if not candidates:
                break

            candidates.sort(key=lambda x: x[1])
            best_idx = candidates[0][0]

            route.append(best_idx)
            used_indices.add(best_idx)

            current = vein_centers[best_idx]
            dist_to_start = math.sqrt(
                (current['x'] - start['x']) ** 2 +
                (current['y'] - start['y']) ** 2 +
                (current['z'] - start['z']) ** 2
            )

            if dist_to_start <= max_jump_distance:
                print("Successfully optimized route to form a loop back to start")
                break

    return route

def generate_multiple_routes(vein_centers, num_routes=num_routes, max_waypoints_per_route=None):
    """Generate multiple optimized routes for mining."""
    max_waypoints_per_route = max_waypoints_per_route or route_length
    routes = []

    is_gemstone = which_ore in gemstone_types
    is_circular = is_gemstone or circular_routes

    print(f"Generating {num_routes} optimized routes...")
    for i in range(num_routes):
        print(f"Generating route {i + 1}/{num_routes}...")
        route = generate_optimized_route(vein_centers, max_waypoints_per_route, is_circular)

        if route:
            routes.append(route)

            if i < num_routes - 1:
                vein_centers_copy = vein_centers.copy()

                for idx in route:
                    vein_centers_copy[idx] = vein_centers_copy[idx].copy()
                    vein_centers_copy[idx]['size'] = max(1, vein_centers_copy[idx]['size'] * 0.4)

                vein_centers = vein_centers_copy

    return routes

def post_process_route(vein_centers, route, smoothing_passes=smoothing_passes, max_y_diff=max_y_diff):
    """Apply post-processing to improve route quality and reduce zigzags."""
    if len(route) < 5:
        return route

    processed_route = route.copy()

    for _ in range(smoothing_passes):
        for i in range(1, len(processed_route) - 2):
            prev = vein_centers[processed_route[i - 1]]
            curr = vein_centers[processed_route[i]]
            next_point = vein_centers[processed_route[i + 1]]
            next_next = vein_centers[processed_route[i + 2]]

            v1 = {
                'x': curr['x'] - prev['x'],
                'y': curr['y'] - prev['y'],
                'z': curr['z'] - prev['z']
            }

            v2 = {
                'x': next_point['x'] - curr['x'],
                'y': next_point['y'] - curr['y'],
                'z': next_point['z'] - curr['z']
            }

            v3 = {
                'x': next_next['x'] - next_point['x'],
                'y': next_next['y'] - next_point['y'],
                'z': next_next['z'] - next_point['z']
            }

            mag_v1 = math.sqrt(v1['x'] ** 2 + v1['y'] ** 2 + v1['z'] ** 2)
            mag_v2 = math.sqrt(v2['x'] ** 2 + v2['y'] ** 2 + v2['z'] ** 2)
            mag_v3 = math.sqrt(v3['x'] ** 2 + v3['y'] ** 2 + v3['z'] ** 2)

            if mag_v1 < 1e-6 or mag_v2 < 1e-6 or mag_v3 < 1e-6:
                continue

            v1_norm = {
                'x': v1['x'] / mag_v1,
                'y': v1['y'] / mag_v1,
                'z': v1['z'] / mag_v1
            }

            v2_norm = {
                'x': v2['x'] / mag_v2,
                'y': v2['y'] / mag_v2,
                'z': v2['z'] / mag_v2
            }

            v3_norm = {
                'x': v3['x'] / mag_v3,
                'y': v3['y'] / mag_v3,
                'z': v3['z'] / mag_v3
            }

            dot_product_1 = (v1_norm['x'] * v2_norm['x'] + v1_norm['y'] * v2_norm['y'] + v1_norm['z'] * v2_norm['z'])
            dot_product_2 = (v2_norm['x'] * v3_norm['x'] + v2_norm['y'] * v3_norm['y'] + v2_norm['z'] * v3_norm['z'])

            y_diff_prev = abs(curr['y'] - prev['y'])
            y_diff_next = abs(next_point['y'] - curr['y'])
            y_diff_next_next = abs(next_next['y'] - next_point['y'])

            # Detect zigzag by checking if the route reverses direction significantly
            if (dot_product_1 < -0.7 and dot_product_2 < -0.7) or \
               (y_diff_prev > max_y_diff or y_diff_next > max_y_diff or y_diff_next_next > max_y_diff):
                # Try to swap with a later waypoint to reduce zigzag
                for j in range(i + 2, min(i + 10, len(processed_route))):
                    if j < len(processed_route):
                        candidate = vein_centers[processed_route[j]]
                        new_y_diff_prev = abs(candidate['y'] - prev['y'])
                        new_y_diff_next = abs(next_point['y'] - candidate['y'])
                        new_y_diff_next_next = abs(next_next['y'] - candidate['y'])

                        # Check directional alignment with preferred direction
                        if preferred_direction == "Z":
                            lateral_deviation = abs(candidate['x'] - curr['x'])
                            forward_progress = candidate['z'] - curr['z']
                        else:  # "X"
                            lateral_deviation = abs(candidate['z'] - curr['z'])
                            forward_progress = candidate['x'] - curr['x']

                        if (new_y_diff_prev <= max_y_diff and new_y_diff_next <= max_y_diff and
                            new_y_diff_next_next <= max_y_diff and forward_progress > 0 and lateral_deviation < max_jump_distance):
                            processed_route[i], processed_route[j] = processed_route[j], processed_route[i]
                            break

    is_gemstone = which_ore in gemstone_types
    is_circular = is_gemstone or circular_routes

    if is_circular:
        start = vein_centers[processed_route[0]]
        end = vein_centers[processed_route[-1]]

        dist = math.sqrt(
            (start['x'] - end['x']) ** 2 +
            (start['y'] - end['y']) ** 2 +
            (start['z'] - end['z']) ** 2
        )

        if dist > max_jump_distance * 0.8:
            optimize_start_idx = max(0, len(processed_route) - len(processed_route) // 3)

            best_dist = dist
            best_segment = processed_route[optimize_start_idx:].copy()

            for i in range(len(best_segment)):
                for j in range(i + 1, len(best_segment)):
                    test_segment = best_segment.copy()
                    test_segment[i], test_segment[j] = test_segment[j], test_segment[i]

                    test_route = processed_route[:optimize_start_idx] + test_segment
                    test_end = vein_centers[test_route[-1]]

                    test_dist = math.sqrt(
                        (start['x'] - test_end['x']) ** 2 +
                        (start['y'] - test_end['y']) ** 2 +
                        (start['z'] - test_end['z']) ** 2
                    )

                    if test_dist < best_dist:
                        best_dist = test_dist
                        best_segment = test_segment.copy()

            processed_route = processed_route[:optimize_start_idx] + best_segment

    return processed_route

def to_soopy_format(vein_centers, route):
    """Convert a route to Soopy/ColeWeight format with offset waypoints for gemstones."""
    is_gemstone = which_ore in gemstone_types
    is_circular = is_gemstone or circular_routes

    soopy_waypoints = []
    for i, route_idx in enumerate(route):
        center = vein_centers[route_idx]

        if is_gemstone:
            offset_x = center['x']
            offset_z = center['z']
            original_y = center['y']

            candidates = [
                {'x': offset_x - 1, 'y': original_y, 'z': offset_z},
                {'x': offset_x + 1, 'y': original_y, 'z': offset_z}
            ]

            def is_gemstone_or_pane_free(pos):
                is_glass_block = any(wp['x'] == pos['x'] and wp['y'] == pos['y'] and wp['z'] == pos['z']
                                     for wp in all_waypoints)
                return not is_glass_block

            valid_candidates = [cand for cand in candidates if is_gemstone_or_pane_free(cand)]
            if valid_candidates:
                new_pos = random.choice(valid_candidates)
                offset_x, offset_y, offset_z = new_pos['x'], new_pos['y'], new_pos['z']
            else:
                offset_x, offset_y, offset_z = center['x'], center['y'], center['z']
        else:
            offset_x, offset_y, offset_z = center['x'], center['y'], center['z']

        progress = i / len(route)

        if is_circular:
            if progress < 0.33:
                r = 1
                g = progress * 3
                b = 0
            elif progress < 0.66:
                r = 1 - (progress - 0.33) * 3
                g = 1
                b = 0
            else:
                r = 0
                g = 1 - (progress - 0.66) * 3
                b = (progress - 0.66) * 3
        else:
            r = progress
            g = 1 - progress
            b = 0

        soopy_waypoints.append({
            "x": offset_x,
            "y": offset_y,
            "z": offset_z,
            "r": int(r * 255),
            "g": int(g * 255),
            "b": int(b * 255),
            "options": {"name": str(i + 1)}
        })
    return soopy_waypoints

def save_to_json(soopy_waypoints, which_ore, route_num):
    """Save waypoints to a JSON file or print JSON string if 'gemstones' folder doesn't exist."""
    gemstones_dir = os.path.join(output_dir, "gemstones")
    import_string = json.dumps(soopy_waypoints)

    if os.path.exists(gemstones_dir):
        output_file = os.path.join(gemstones_dir, f"{which_ore}_route_{route_num}.json")
        os.makedirs(gemstones_dir, exist_ok=True)
        with open(output_file, 'w') as f:
            json.dump(soopy_waypoints, f, indent=2)
        print(f"Route {route_num} for {which_ore} saved to {output_file} with {len(soopy_waypoints)} waypoints")

        print(f"\nColeWeight/Soopy import string for Route {route_num}:")
        print(import_string)
        print(f"To import in ColeWeight: Copy the string above, then in-game use /cw ordered load")
        print(f"To import in Soopy: Copy the above string, then in-game use /loadwaypoints followed by /converttoorder")
    else:
        print(f"\n'gemstones' folder not found in {output_dir}. Printing JSON string for Route {route_num}:")
        print(f"ColeWeight/Soopy import string for Route {route_num}:")
        print(import_string)
        print(f"To import in ColeWeight: Copy the above string, then in-game use /cw ordered load")
        print(f"To import in Soopy: Copy the above string, then in-game use /loadwaypoints followed by /converttoorder")

def calculate_route_stats(vein_centers, route):
    """Calculate and display statistics about a route."""
    total_distance = 0
    total_blocks = 0
    jumps = []
    y_changes = []

    for i in range(len(route) - 1):
        current = vein_centers[route[i]]
        next_point = vein_centers[route[i + 1]]

        dist = math.sqrt(
            (next_point['x'] - current['x']) ** 2 +
            (next_point['y'] - current['y']) ** 2 +
            (next_point['z'] - current['z']) ** 2
        )
        y_diff = abs(next_point['y'] - current['y'])
        total_distance += dist
        jumps.append(dist)
        y_changes.append(y_diff)

        total_blocks += current['size']

    is_gemstone = which_ore in gemstone_types
    is_circular = is_gemstone or circular_routes
    if is_circular and len(route) > 1:
        start = vein_centers[route[0]]
        end = vein_centers[route[-1]]
        dist_to_start = math.sqrt(
            (start['x'] - end['x']) ** 2 +
            (start['y'] - end['y']) ** 2 +
            (start['z'] - end['z']) ** 2
        )
        if dist_to_start <= max_jump_distance:
            total_distance += dist_to_start
            jumps.append(dist_to_start)
            y_diff = abs(start['y'] - end['y'])
            y_changes.append(y_diff)
        else:
            print("Warning: Route is not fully circular (end-to-start distance exceeds max_jump_distance)")

    if route:
        total_blocks += vein_centers[route[-1]]['size']

    avg_jump = total_distance / (len(jumps) if jumps else 1)
    max_jump = max(jumps) if jumps else 0
    min_jump = min(jumps) if jumps else 0
    avg_y_change = sum(y_changes) / (len(y_changes) if y_changes else 1)
    max_y_change = max(y_changes) if y_changes else 0

    print(f"\nRoute Statistics:")
    print(f"Total Distance: {total_distance:.2f} blocks")
    print(f"Total Blocks Mined: {total_blocks}")
    print(f"Average Jump Distance: {avg_jump:.2f} blocks")
    print(f"Maximum Jump Distance: {max_jump:.2f} blocks")
    print(f"Minimum Jump Distance: {min_jump:.2f} blocks")
    print(f"Average Y-Change: {avg_y_change:.2f} blocks")
    print(f"Maximum Y-Change: {max_y_change:.2f} blocks")
    print(f"Number of Jumps: {len(jumps)}")

    return total_distance, total_blocks, jumps

def main():
    """Main function to generate mining routes."""
    global all_waypoints

    if not isinstance(num_routes, int) or num_routes <= 0:
        print(f"Error: 'num_routes' must be a positive integer, got {num_routes}")
        return

    if which_ore not in ore_types:
        print(f"Error: '{which_ore}' is not a supported ore. Choose from: {list(ore_types.keys())}")
        return

    target_block_id, target_data_value = ore_types[which_ore]
    print(f"Extracting {which_ore} locations from world file...")
    all_waypoints.clear()
    all_waypoints = extract_ore_locations(world_folder, target_block_id, target_data_value)

    if not all_waypoints:
        print(f"No {which_ore} blocks found under Y={max_y}.")
        return

    print("Grouping ore blocks into veins...")
    start_time = time.time()
    veins = group_into_veins(all_waypoints)
    end_time = time.time()
    print(f"Grouping took {end_time - start_time:.2f} seconds")

    print("Calculating vein center waypoints...")
    vein_centers = calculate_vein_centers(veins)

    print("Generating optimized routes...")
    start_time = time.time()
    routes = generate_multiple_routes(vein_centers)
    end_time = time.time()
    print(f"Route generation took {end_time - start_time:.2f} seconds")

    print("Post-processing routes...")
    processed_routes = [post_process_route(vein_centers, route) for route in routes]

    print("Converting routes to Soopy/ColeWeight format and saving...")
    for i, route in enumerate(processed_routes, 1):
        soopy_waypoints = to_soopy_format(vein_centers, route)
        save_to_json(soopy_waypoints, which_ore, i)
        calculate_route_stats(vein_centers, route)

if __name__ == "__main__":
    main()

# Copyright (c) 2025 Luka
# This script is licensed under the MIT License. See the LICENSE file for details.